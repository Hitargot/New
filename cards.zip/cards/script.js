// Canvas
const canvas = document.querySelector('canvas.webgl')

// Scene
const scene = new THREE.Scene()

const textureLoader = new THREE.TextureLoader()
const texture1 = textureLoader.load('./static/car1.png')
const texture2 = textureLoader.load('./static/car2.png')
const texture3 = textureLoader.load('./static/car3.png')
const texture4 = textureLoader.load('./static/car4.png')
const texture5 = textureLoader.load('./static/car5.png')
const texture6 = textureLoader.load('./static/car6.png')
const texture7 = textureLoader.load('./static/car7.png')
const texture8 = textureLoader.load('./static/car8.png')
const texture9 = textureLoader.load('./static/car9.png')
const texture10 = textureLoader.load('./static/car10.png')
const texture11 = textureLoader.load('./static/car11.png')
const texture12 = textureLoader.load('./static/car12.png')

const planeMaterial = new THREE.ShaderMaterial({
    uniforms:
    {
        uTime: { value: 0 },
        uTexture1: {value: texture1},
        uTexture2: {value: texture2},
        uTexture3: {value: texture3},
        uTexture4: {value: texture4},
        uTexture5: {value: texture5},
        uTexture6: {value: texture6},
        uTexture7: {value: texture7},
        uTexture8: {value: texture8},
        uTexture9: {value: texture9},
        uTexture10: {value: texture10},
        uTexture11: {value: texture11},
        uTexture12: {value: texture12},
        uAngle: {value: 0}
    },    
    vertexShader: `
    uniform float uTime;

    varying vec2 vUv;

    void main()
    {
        vUv = uv;

        vec4 modelPosition = modelMatrix * vec4(position, 1.0);


        vec4 viewPosition = viewMatrix * modelPosition;
        vec4 projectedPosition = projectionMatrix * viewPosition;
        gl_Position = projectedPosition;

    }
    `,
    fragmentShader: `
    uniform float uTime;
    uniform float uAngle;
        
    uniform sampler2D uTexture1;
    uniform sampler2D uTexture2;
    uniform sampler2D uTexture3;
    uniform sampler2D uTexture4;
    uniform sampler2D uTexture5;
    uniform sampler2D uTexture6;
    uniform sampler2D uTexture7;
    uniform sampler2D uTexture8;
    uniform sampler2D uTexture9;
    uniform sampler2D uTexture10;
    uniform sampler2D uTexture11;
    uniform sampler2D uTexture12;

    varying vec2 vUv;

    void main()
    {
        vec3 texture1 = texture2D(uTexture1, vUv).rgb;
        vec3 texture2 = texture2D(uTexture2, vUv).rgb;
        vec3 texture3 = texture2D(uTexture3, vUv).rgb;
        vec3 texture4 = texture2D(uTexture4, vUv).rgb;
        vec3 texture5 = texture2D(uTexture5, vUv).rgb;
        vec3 texture6 = texture2D(uTexture6, vUv).rgb;
        vec3 texture7 = texture2D(uTexture7, vUv).rgb;
        vec3 texture8 = texture2D(uTexture8, vUv).rgb;
        vec3 texture9 = texture2D(uTexture9, vUv).rgb;
        vec3 texture10 = texture2D(uTexture10, vUv).rgb;
        vec3 texture11 = texture2D(uTexture11, vUv).rgb;
        vec3 texture12 = texture2D(uTexture12, vUv).rgb;
    
        float mixFactor = ((uAngle * 0.5 + 0.5) * 12.0);
    
        vec3 mixedColor = mix(texture1, texture2, smoothstep(0.5, 1.5, mixFactor));
        mixedColor = mix(mixedColor, texture3, smoothstep(1.5, 2.5, mixFactor));
        mixedColor = mix(mixedColor, texture4, smoothstep(2.5, 3.5, mixFactor));
        mixedColor = mix(mixedColor, texture5, smoothstep(3.5, 4.5, mixFactor));
        mixedColor = mix(mixedColor, texture6, smoothstep(4.5, 5.5, mixFactor));
        mixedColor = mix(mixedColor, texture7, smoothstep(5.5, 6.5, mixFactor));
        mixedColor = mix(mixedColor, texture8, smoothstep(6.5, 7.5, mixFactor));
        mixedColor = mix(mixedColor, texture9, smoothstep(7.5, 8.5, mixFactor));
        mixedColor = mix(mixedColor, texture10, smoothstep(8.5, 9.5, mixFactor));
        mixedColor = mix(mixedColor, texture11, smoothstep(9.5, 10.5, mixFactor));
        mixedColor = mix(mixedColor, texture12, smoothstep(10.5, 11.5, mixFactor));
    
        gl_FragColor = vec4(vec3(mixedColor), 1.0);
    }`
})

const card = new THREE.Mesh(
    new THREE.PlaneGeometry(3, 4, 1, 1),
    planeMaterial
)

scene.add(card)


//Sizes

const sizes = {
    width: canvas.clientWidth,
    height: canvas.clientHeight
}

window.addEventListener('resize', () =>
{
    // Update sizes
    sizes.width = canvas.clientWidth
    sizes.height = canvas.clientHeight

    // Update camera
    camera.aspect = sizes.width / sizes.height
    camera.updateProjectionMatrix()

    // Update renderer
    renderer.setSize(sizes.width, sizes.height)
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))
})


//Camera

const camera = new THREE.PerspectiveCamera(75, sizes.width / sizes.height, 0.1, 100)
camera.position.x = 0
camera.position.y = 0
camera.position.z = 4
scene.add(camera)


const renderer = new THREE.WebGLRenderer({
    canvas: canvas,
    antialias: true
})
renderer.setSize(sizes.width, sizes.height)
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))

const controls = new THREE.OrbitControls(camera, canvas)
controls.enableDamping = true
controls.enableZoom = false


const clock = new THREE.Clock()

const tick = () =>
{
   const elapsedTime = clock.getElapsedTime()

   // Update material
   planeMaterial.uniforms.uAngle.value = controls.getAzimuthalAngle() / (Math.PI / 2)

   // Update controls
   controls.update()

   // Render
   renderer.render(scene, camera)

   // Call tick again on the next frame
   window.requestAnimationFrame(tick)
}

tick()